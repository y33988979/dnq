Example 1
=========

Close to the simplest possible example of Unity, using only basic features.
Run make to build & run the example tests.